#from openpyxl import Workbook
class_name = ["test something", "boring class", "else"]
class_day = ["Monday", "Sunday", "Friday"]
remember = ("test something")
class_time = ["11:40", "12:30", "other"]
class_teacher = ["test something"]
situation = ("test something")
class_category = ["test something"]
class_description = ["test something"]
class_and_category = ["test something"]
hidden_info = ["test something"]
personal_class = ["test something"]
saves = ["class_name", "class_day", "class_time", "class_teacher", "class_category", "class_description",
         "class_and_category", "hidden_info", "personal_class"]
days = ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def student_only():
    result = input(str(class_category) + "\n which category would you like to chose by?")
    if result in class_category:
        if result in class_category:
            if result in hidden_info:
                start = int(hidden_info.index(result))
                end = int(hidden_info.count(result) + start)
                both = [start, end]
                both.sort()
                start_2 = both[0]
                end_2 = both[1]
                result = input((str(class_name[start_2:end_2]) + "\nwhich class would you like to show?"))
                if result in class_name:
                    personal_class.append(result)
student_only()