eternity = ("10")
class_description = []
class_time = []
class_name = []
class_category = []
hidden_info = []
hidden_info_2 = []
hidden_info_3 = []
blank = ("")
last = []
def loading():
    global class_name, class_time, class_description, class_category, hidden_info_2, hidden_info_3, last
    load = open("savefile.txt", "r+")
    file_lines = load.readlines()
    class_name = (file_lines[0].rstrip().split(","))
    class_time = (file_lines[1].rstrip().split(","))
    class_description = (file_lines[2].rstrip().split(","))
    class_category = (file_lines[3].rstrip().split(","))
    hidden_info_2 = (file_lines[4].rstrip().split(","))
    hidden_info_3 = (file_lines[5].rstrip().split(","))
    print(class_name)
    load.close()
def adding_2():

    class_category_secondary = (input("would you like to add a category for the class? please write yes or no"))
    if class_category_secondary == "yes":
        print(class_category)
        print("write the name of a category to insert the class to the category")
        category = input("")
        last.append(category)
        if category in class_category:
            hidden_info_2.append(hidden_info)
            hidden_info_3.append(category)
        else:
            print("it seems there's an issue, please try again")
    elif class_category_secondary == "no":
       print("the following class will have no category")
    else:
        print("please write yes or no")
        adding_2()
    class_time.append(input("add a time to the class\n"))
    class_description.append(input("add a description to the class\n"))
    normal()
def adding():
    failure = False
    global hidden_info, hidden_info_2
    print("would you like to make a category or a class?")
    answer = input("class\category \n")
    if answer == "class":
       hidden_info = input("add a name to the class\n")
       class_name.append(hidden_info)
       class_category_secondary = (input("would you like to add a category for the class? please write yes or no"))
       if class_category_secondary == "yes":
           print(class_category)
           print("write the name of a category to insert the class to the category")
           category = input("")
           last.append(category)
           if category in class_category:
               hidden_info_2.append(hidden_info)
               hidden_info_3.append(category)
           else:
               print("it seems there's an issue, please try again")
       elif class_category_secondary == "no":
          print("the following class will have no category")
       else:
           print("please write yes or no")
           adding_2()
       if failure is False:
          class_time.append(input("add a time to the class\n"))
          class_description.append(input("add a description to the class\n"))
       else:
           failure = False
    elif answer == "category":
        print("please write a name for the category")
        class_category.append(input(""))
    else:
        print("please write class or category")
        adding()
print("this is version 0.3 of the classification system")
print("you can use this system to handle you classes and their dates better")
print("here's your current options: \n")
print("add - make new classes or categories and describe them")
print("delete - choose a class and delete it")
print("show - view all classes and their dates\description")
print("save - save your current classes, add them back with load")
print("load - brings you the last saved list of classes")
print("options - shows all options you have \n")
option_1 = ["add"]
option_2 = ["delete"]
option_3 = ["show"]
option_4 = ["save"]
option_5 = ["load"]
option_6 = ["options"]
def loop():
    print("please write add or load")
    players_choice = input("")
    if players_choice in option_1:
        adding()
    elif players_choice in option_5:
        loading()
    else:
       loop()
players_choice = input("because you dont have any classes yet, please add some or load \n")
if players_choice in option_1:
    adding()
elif players_choice in option_5:
    loading()
else:
   loop()
def showing():
    answer = input("would you like to search by category? please write yes or no")
    if answer == "no":
      number = len(class_name)
      print(class_name[0:number])
      print("which class would you like to view?")
      specific_class_2 = (input(" "))
      if specific_class_2 in class_name:
          specific_class = class_name.index(specific_class_2)
          print(class_name[specific_class])
          print(class_time[specific_class])
          print(class_description[specific_class])
    elif answer == "yes":
        print(class_category)
        number = input("which category would you like to chose by?")
        if number in class_category:
            if number in hidden_info_3:
                print(hidden_info_2)
                print("which class would you like to view?")
                specific_class_2 = (input(" "))
                if specific_class_2 in class_name:
                    specific_class = class_name.index(specific_class_2)
                    print(class_name[specific_class])
                    print(class_time[specific_class])
                    print(class_description[specific_class])
                else:
                    print("it seems there's a mistake, please try again")
                    showing()
        else:
           print("it seems there's a mistake, please try again")
           showing()
    else:
        print("it seems there's a mistake, please try again")
        showing()
print("from now on, you are free to do anything you want")
def removing():
    answer = input("would you like to search by category? please write yes or no")
    if answer == "no":
       print(class_name)
       print("which class would you like to delete?")
       specific_class = class_name.index(input(""))
       if specific_class in class_name:
          class_name.pop(specific_class)
          class_time.pop(specific_class)
          class_description.pop(specific_class)
       else:
           print("it seems there's a mistake, please try again")
           removing()
    elif answer == "yes":
        print(class_category)
        number = input("which category would you like to chose by?")
        if number in class_category:
            if number in hidden_info_3:
                print(hidden_info_2)
                print("which class would you like to delete?")
                specific_class = class_name.index(input(""))
                if specific_class in class_name:
                    class_name.pop(specific_class)
                    class_name.pop(specific_class)
                    class_description.pop(specific_class)
                else:
                    print("it seems there's a mistake, please try again")
                    removing()
    else:
        print("it seems there's a mistake, please try again")
        removing()
def saving():
    number = len(class_name)
    save_file = open("savefile.txt", "w")
    save_file.write(str(','.join(class_name[0:number]) + "\n"))
    save_file.write(str(','.join(class_time[0:number]) + "\n"))
    save_file.write(str(','.join(class_description[0:number]) + "\n"))
    save_file.write(str(','.join(class_category[0:number]) + "\n"))
    save_file.write(str(','.join(hidden_info_2) + "\n"))
    save_file.write(str(','.join(last) + "\n"))
    print("all classes have been saved")
    save_file.close()
def options():
    print("here's your current options: \n")
    print("add - make new classes or categories and describe them")
    print("delete - choose a class and delete it")
    print("show - view all classes and their dates\description")
    print("save - save your current classes, add them back with load")
    print("load - brings you the last saved list of classes")
    print("options - shows all options you have")
def normal():
    while eternity == ("10"):
       players_choice = (input("what would you like to do?"))
       if players_choice in option_1:
           adding()
       elif players_choice in option_3:
           showing()
       elif players_choice in option_2:
           removing()
       elif players_choice in option_4:
           saving()
       elif players_choice in option_5:
           loading()
       elif players_choice in option_6:
           options()
       else:
           print("please write a command, if you dont know what commands do you have then write options")
normal()