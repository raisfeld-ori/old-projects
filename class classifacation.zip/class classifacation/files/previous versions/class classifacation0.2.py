eternity = ("10")
print("this is version 0.01 of the classification system")
print("the point of the system is to control which classes are open for students")
print("your options are add, delete and show classes and save class")
option_1 = ["add"]
option_2 = ["delete"]
option_3 = ["show classes"]
option_4 = ["save"]
players_choice = input("because you dont have any classes yet, please add some")
if players_choice in option_1:
    print("")
else:
    print("your answer hasn't been recognized as add, however we'll still consider it as add")
class_name = []
class_name.append(input("add a name to the class"))
class_time = []
class_time.append(input("add a time to the class"))
class_description = []
class_description.append(input("add a description to the class"))
def adding():
    class_name.append(input("add a name to the class"))
    class_time.append(input("add a time to the class"))
    class_description.append(input("add a description to the class"))
def showing():
    print(class_name)
    print("which class would you like to view?")
    specific_class = class_name.index(input(""))
    print(class_name[specific_class])
    print(class_time[specific_class])
    print(class_description[specific_class])
print("from now on, you are free to do anything you want")
def removing():
    print(class_name)
    print("which class would you like to delete?")
    specific_class = class_name.index(input(""))
    class_name.pop(specific_class)
    class_time.pop(specific_class)
    class_description.pop(specific_class)
def saving():
    save_file = open("savefile.txt", "w")
    save_file.write(str(class_name))
    save_file.write(str(class_time))
    save_file.write(str(class_description))
    print("all classes have been saved")
    save_file.close()
while eternity == ("10"):
    players_choice = (input("what would you like to do?"))
    if players_choice in option_1:
        adding()
    elif players_choice in option_3:
        showing()
    elif players_choice in option_2:
        removing()
    elif players_choice in option_4:
        saving()
    else:
        print("please write add, delete, show classes or save")