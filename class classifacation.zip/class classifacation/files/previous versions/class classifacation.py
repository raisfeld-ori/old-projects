def unrecognized():
    print("please write add")
    players_choice = input("write add in order to move on")
print("this is version 0.01 of the classification system")
print("the point of the system is to control which classes are open for students")
print("your options are add and delete")
options = ["add"]
players_choice = input("because you dont have any classes yet, please add some")
if players_choice in options:
    print("")
else:
    while players_choice not in options:
        unrecognized()
        if players_choice in options:
            print("version should end now")
print("end of version")