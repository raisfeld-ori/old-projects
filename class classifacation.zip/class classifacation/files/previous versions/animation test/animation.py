import turtle
from tkinter import *
wn = turtle.Screen()
wn.title("class classifacation demo")
wn.bgcolor("light blue")
images = 200
options = ["add", "delete", "show", "save", "load", "options"]
shapes = ["add.gif"]
def cordintates(x, y):
    print(str(x) + " " + str(y))
wn.onclick(cordintates)
wn.mainloop()
