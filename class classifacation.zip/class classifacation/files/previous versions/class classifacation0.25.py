eternity = ("10")
class_description = []
class_time = []
class_name = []
def loading():
    load = open("savefile.txt", "r")
    class_name.append(load.readline().splitlines())
    print(class_name)
print("this is version 0.3 of the classification system")
print("the point of the system is to control which classes are open for students")
print("your options are add, delete and show classes and save class")
option_1 = ["add"]
option_2 = ["delete"]
option_3 = ["show"]
option_4 = ["save"]
option_5 = ["load"]
option_6 = ["saving"]
players_choice = input("because you dont have any classes yet, please add some or load \n")
if players_choice in option_1:
    class_name.append(input("add a name to the class\n"))
    class_time.append(input("add a time to the class\n"))
    class_description.append(input("add a description to the class\n"))
else:
    print("your answer hasn't been recognized as add, however we'll still consider it as add")
    class_name.append(input("add a name to the class\n"))
    class_time.append(input("add a time to the class\n"))
    class_description.append(input("add a description to the class\n"))
def adding():
    class_name.append(input("add a name to the class\n"))
    class_time.append(input("add a time to the class\n"))
    class_description.append(input("add a description to the class\n"))
def showing():
    print(class_name)
    print("which class would you like to view?")
    specific_class = class_name.index(input("\n"))
    print(class_name[specific_class])
    print(class_time[specific_class])
    print(class_description[specific_class])
print("from now on, you are free to do anything you want")
def removing():
    print(class_name)
    print("which class would you like to delete?")
    specific_class = class_name.index(input(""))
    class_name.pop(specific_class)
    class_time.pop(specific_class)
    class_description.pop(specific_class)
def saving():
    number = len(class_name)
    save_file = open("savefile.txt", "w")
    save_file.write(str(','.join(class_name[0:number]) + "\n"))
    save_file.write(str(','.join(class_time[0:number]) + "\n"))
    save_file.write(str(','.join(class_description[0:number]) + "\n"))
    print("all classes have been saved")
    save_file.close()
def saving2():
    number = len(class_name)
    print(class_name[0:number])
while eternity == ("10"):
    players_choice = (input("what would you like to do?"))
    if players_choice in option_1:
        adding()
    elif players_choice in option_3:
        showing()
    elif players_choice in option_2:
        removing()
    elif players_choice in option_4:
        saving()
    elif players_choice in option_5:
        loading()
    elif players_choice in option_6:
        saving2()
    else:
        print("please write add, delete, show classes or save")