eternity = ("10")
class_description = []
class_time = []
class_name = []
class_category = []
hidden_info = []
hidden_info_2 = []
hidden_info_3 = []
last = []
making_sure = True
personal_class = []
def loading():
    global class_name, class_time, class_description, class_category, hidden_info_2, hidden_info_3, last, making_sure
    load = open("savefile.txt", "r+")
    file_lines = load.readlines()
    if making_sure == ("True"):
        class_name = (file_lines[0].rstrip().split(","))
        class_time = (file_lines[1].rstrip().split(","))
        class_description = (file_lines[2].rstrip().split(","))
    else:
       class_name = (file_lines[0].rstrip().split(","))
       class_time = (file_lines[1].rstrip().split(","))
       class_description = (file_lines[2].rstrip().split(","))
       class_category = (file_lines[3].rstrip().split(","))
       hidden_info_2 = (file_lines[4].rstrip().split(","))
       hidden_info_3 = (file_lines[5].rstrip().split(","))
    load.close()
def options():
    print("here's your current options: \n")
    print("add - add classes to your chosen classes")
    print("show - view all classes or chosen classes")
    print("save - save your current chosen classes, add them back with load")
    print("load - brings you the last saved list of classes")
    print("my classes - shows your chosen classes")
    print("all classes - shows all classes")
    print("options - shows all options you have")
def adding():
    answer = input("would you like to search by category? please write yes or no")
    if answer == "no":
      number = len(class_name)
      print(class_name[0:number])
      print("which class would you like to add to 'my classes'?")
      specific_class_2 = (input(" "))
      if specific_class_2 in class_name:
          personal_class.append(specific_class_2)
    elif answer == "yes":
        print(class_category)
        number = input("which category would you like to chose by?")
        if number in class_category:
                print(hidden_info_2)
                print("which class would you like to add to 'my classes'?")
                specific_class_2 = (input(" "))
                if specific_class_2 in class_name:
                    personal_class.append(specific_class_2)
                else:
                    print("it seems there's a mistake, please try again")
                    adding()
        else:
           print("it seems there's a mistake, please try again")
           adding()
    else:
        print("it seems there's a mistake, please try again")
        adding()
print("this is version 0.3 of the classification system")
option_1 = ["add"]
option_2 = ["delete"]
option_3 = ["show"]
option_4 = ["save"]
option_5 = ["load"]
option_6 = ["options"]
def showing():
    answer = input("would you like to search by category? please write yes or no")
    if answer == "no":
      number = len(class_name)
      print(class_name[0:number])
      print("which class would you like to view?")
      specific_class_2 = (input(" "))
      if specific_class_2 in class_name:
          specific_class = class_name.index(specific_class_2)
          print(class_name[specific_class])
          print(class_time[specific_class])
          print(class_description[specific_class])
          if specific_class_2 in personal_class:
              print("you added this class to 'my classes'")
    elif answer == "yes":
        print(class_category)
        number = input("which category would you like to chose by?")
        if number in class_category:
                print(hidden_info_2)
                print("which class would you like to view?")
                specific_class_2 = (input(" "))
                if specific_class_2 in class_name:
                    specific_class = class_name.index(specific_class_2)
                    print(class_name[specific_class])
                    print(class_time[specific_class])
                    print(class_description[specific_class])
                    if specific_class_2 in personal_class:
                        print("this class was added to 'my classes'")
                else:
                    print("it seems there's a mistake, please try again")
                    showing()
        else:
           print("it seems there's a mistake, please try again")
           showing()
    else:
        print("it seems there's a mistake, please try again")
        showing()
print("from now on, you are free to do anything you want")
def removing():
    answer = input("would you like to search by category? please write yes or no")
    if answer == "no":
        number = len(personal_class)
        print(personal_class[0:number])
        print("which class would you like to remove from 'my classes'?")
        specific_class_2 = (input(" "))
        if specific_class_2 in class_name:
            personal_class.remove(specific_class_2)
    elif answer == "yes":
        print(class_category)
        number = input("which category would you like to chose by?")
        if number in class_category:
                combined_classes = []
                for element in hidden_info_2:
                    if element in personal_class:
                        combined_classes.append(element)
                print(combined_classes)
                print("which class would you like to remove from 'my classes'?")
                specific_class_2 = (input(" "))
                if specific_class_2 in class_name:
                    personal_class.remove(specific_class_2)
                else:
                    print("it seems there's a mistake, please try again")
                    removing()
        else:
            print("it seems there's a mistake, please try again")
            removing()
    else:
        print("it seems there's a mistake, please try again")
        removing()
def saving():
        number = len(personal_class)
        studant_save_file = open("savefile.txt", "w")
        studant_save_file.write(str(','.join(personal_class[0:number]) + "\n"))
        studant_save_file.close()
print("write options to view your commands")
def normal():
    while eternity == ("10"):
       players_choice = (input("what would you like to do?"))
       if players_choice in option_1:
           adding()
       elif players_choice in option_3:
           showing()
       elif players_choice in option_2:
           removing()
       elif players_choice in option_4:
           saving()
       elif players_choice in option_5:
           loading()
       elif players_choice in option_6:
           options()
       else:
           print("please write a command, if you dont know what commands do you have then write options")
loading()
normal()